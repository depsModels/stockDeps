CREATE DATABASE  IF NOT EXISTS `basic-mvc`;
USE `basic-mvc`;